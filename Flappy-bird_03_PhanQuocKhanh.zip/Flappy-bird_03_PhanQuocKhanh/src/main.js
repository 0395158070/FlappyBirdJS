var canvas = document.getElementById('gamezone');
var context = canvas.getContext('2d');
var scoreshow = document.getElementById('score');

var fly = new Audio();
var scor = new Audio();

fly.src = "sounds/fly.mp3";
scor.src = "sounds/score.mp3";

var birdimg = new Image();
birdimg.src = "images/bird.png";
birdimg.size="200px";

var hinhnenchinh = new Image();
hinhnenchinh.src = "images/nenchinh.png";

var ongtren = new Image();
ongtren.src = "images/ongtren.png";

var ongduoi = new Image();
ongduoi.src = "images/ongduoi.png";

var score = 0;
var khoangcachhaiong = 140;
var khoangcachdenongduoi;

var bird = {
    x: hinhnenchinh.width,
    y: hinhnenchinh.height
}
var ong = [];
ong[0] = {
    x: canvas.width,
    y: 0
}


function run() {
   
    context.drawImage(hinhnenchinh, 0, 0);
    context.drawImage(birdimg, bird.x, bird.y);

    for(var i = 0; i < ong.length; i++) {
        khoangcachdenongduoi = ongtren.height + khoangcachhaiong;
        context.drawImage(ongtren, ong[i].x, ong[i].y);
        // vẽ ống trên theo tọa độ của ống đó
        // ống dưới phụ thuộc ống trên
        context.drawImage(ongduoi, ong[i].x, ong[i].y + khoangcachdenongduoi);
        // lấy vị trí ống trên cộng khoảng cách đến ống dưới
        
        ong[i].x -= 3;

        
        if(ong[i].x == canvas.width/1.2){
            ong.push ({
                x:canvas.width,
                y:Math.floor(Math.random() * ongtren.height) - ongtren.height
            })
        }

        if(ong[i].x == 0){
            score++;
            scor.play();
        }

        // nếu ống đụng lề trái thì xóa nó đi để tránh mảng ống
        if(ong[i].x == bird.x){
            ong.splice(0, 1);
        }

        // function thua
        if(bird.y + birdimg.height == canvas.height || 
        bird.x + birdimg.width >= ong[i].x && bird.x <= ong[i].x + ongtren.width && (bird.y <= ong[i].y+ongtren.height ||
        bird.y + birdimg.height >= ong[i].y + khoangcachdenongduoi)){
            return;
        }                   
    }
    // Điều kiện đầu tiên là đụng đất
    // NOTE: tính tọa độ y cộng với độ cao con chim
    // Điều kiện thứ hai là so sánh vị trí x con chim với cái ống 
    // Điều kiện cuối cùng là so sánh vị trí y

    scoreshow.innerHTML = "Điểm của bạn: " + score;
    
    bird.y += 4;
    
    requestAnimationFrame(run);
}

document.addEventListener(
    "keydown",
    function() {
        bird.y -= 60;
        fly.play();
    }
)
run();